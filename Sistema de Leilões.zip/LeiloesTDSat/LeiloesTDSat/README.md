LeiloesTDSat
O projeto se trata de um software feito para uma casa de leilão para cadastrar, listar e gerenciar produtos que serão leiloados.
As tecnologias utilizadas para este projeto foram o Java Netbeans e  o MySQL Workbench.
